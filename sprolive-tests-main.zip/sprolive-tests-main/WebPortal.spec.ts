import {expect} from '@playwright/test'
import {test} from '../test-options'
import {WebPortalNavigationPage} from '../page-objects/WebPortalNavigationPage'
import { Faker } from "@faker-js/faker/.";


