import {expect} from '@playwright/test'
import {test} from '../test-options'
import {ModulesNavigationPage} from '../page-objects/ModulesNavigationPage'
import { Faker } from "@faker-js/faker/.";


